//
//  SOAPMethods.m
//  CocoaAMF-iPhone
//
//  Created by Marc Bauer on 11.01.09.
//  Copyright 2009 nesiumdotcom. All rights reserved.
//

#import "SOAPMethods.h"
#import "ConstantsAndMacros.h"
#import <objc/message.h>

@implementation SOAPMethods

@synthesize delegate=m_delegate;

#pragma mark -
#pragma mark Initialization & Deallocation

- (id)init
{
	if (self == [super init])
	{
		m_remotingCall = [[SOAPRemotingCall alloc] init];
		m_remotingCall.URL = [NSURL URLWithString:WEB_URL];
		//m_remotingCall.service = @"TBAService";
		m_remotingCall.delegate = self;
		m_delegate = nil;
	}
	return self;
}

- (void)dealloc
{
	[m_remotingCall release];
	[super dealloc];
}

#pragma mark -
#pragma mark Public methods

-(void)call_SearchUser:(NSString *)UserName
{
    m_remotingCall.method = WEB_METHOD_SearchUser;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserName forKey:@"UserName"];	
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}
-(void)call_AddFriend:(NSString *)UserName setFriendName:(NSString *)FriendName
{
    m_remotingCall.method = WEB_METHOD_AddFriend;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserName forKey:@"UserName"];
    [dict setValue:FriendName forKey:@"FriendName"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
    
}

-(void)call_ListMyFriend:(NSString *)UserID
{
    m_remotingCall.method = WEB_METHOD_ListMyFriend;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserID forKey:@"UserID"];    
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
    
}

-(void)call_ListQuestion:(NSString *)GameId setReset:(NSString *)Reset
{
    m_remotingCall.method = WEB_METHOD_ListQuestion;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:GameId forKey:@"GameId"];
    [dict setValue:Reset forKey:@"Reset"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
    
}

-(void)call_DeleteFriend:(NSString *)UserName setFriendName:(NSString *)FriendName
{
    m_remotingCall.method = WEB_METHOD_DeleteFriend;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserName forKey:@"UserName"];
    [dict setValue:FriendName forKey:@"FriendName"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}
-(void)call_AuthenticateUser:(NSString *)UserName setEmail:(NSString *)Email setPassword:(NSString *)Password setDeviceID:(NSString *)DeviceID 
{
    m_remotingCall.method = WEB_METHOD_AuthenticateUser;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserName forKey:@"UserName"];
    [dict setValue:Email forKey:@"Email"];
    [dict setValue:Password forKey:@"Password"];
    [dict setValue:DeviceID forKey:@"DeviceID"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];

}
-(void)call_EditProfile:(NSString *)UserId setUserName:(NSString *)UserName setEmail:(NSString *)Email setPassword:(NSString *)Password setImageData:(NSString *)ImageData
{
    m_remotingCall.method = WEB_METHOD_EditProfile;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserId forKey:@"UserId"];
    [dict setValue:UserName forKey:@"UserName"];
    [dict setValue:Email forKey:@"Email"];
    [dict setValue:Password forKey:@"Password"];
    [dict setValue:ImageData forKey:@"ImageData"];
    NSLog(@"dict::%@",dict);
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_UserRegister:(NSString *)UserName setEmail:(NSString *)Email setDeviceID:(NSString *)DeviceID
{
    m_remotingCall.method = WEB_METHOD_UserRegister;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserName forKey:@"UserName"];
    [dict setValue:Email forKey:@"Email"];
    [dict setValue:DeviceID forKey:@"DeviceID"];
   	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];

}


-(void)call_SendInvitation:(NSString *)UserName setFriendName:(NSString *)FriendName setLanguageID:(NSString *)LanguageID
{
    m_remotingCall.method = WEB_METHOD_SendInvitation;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserName forKey:@"UserName"];
    [dict setValue:FriendName forKey:@"FriendName"];
    [dict setValue:LanguageID forKey:@"LanguageID"];
   	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_CheckDevice:(NSString *)UserId setDeviceID:(NSString *)DeviceID
{
    m_remotingCall.method = WEB_METHOD_CheckDevice;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserId forKey:@"UserId"];
    [dict setValue:DeviceID forKey:@"DeviceID"];    
   	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];

}

-(void)call_SetBadgeCount:(NSString *)BadgeCount setDeviceID:(NSString *)DeviceID
{
    m_remotingCall.method = WEB_METHOD_SetBadgeCount;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
   	[dict setValue:BadgeCount forKey:@"BadgeCount"];
    [dict setValue:DeviceID forKey:@"DeviceId"];
    
   	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_UpdateStatus:(NSString *)GameId
{
    m_remotingCall.method = WEB_METHOD_UpdateStatus;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:GameId forKey:@"GameId"];   
   	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}


-(void)call_DeleteGame:(NSString *)GameId setUserID:(NSString *)UserID
{
    m_remotingCall.method = WEB_METHOD_DeleteGame;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:GameId forKey:@"GameId"];
    [dict setValue:UserID forKey:@"UserID"];
   	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_UpdateScoreCard:(NSString *)UserName setGameId:(NSString *)GameId setScore:(NSString *)Score setGameProcessId:(NSString *)GameProcessId setUserAnswer:(NSString *)UserAnswer 
{
    m_remotingCall.method = WEB_METHOD_UpdateScoreCard;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserName forKey:@"UserName"];
    [dict setValue:GameId forKey:@"GameId"];
    [dict setValue:Score forKey:@"Score"];
    [dict setValue:GameProcessId forKey:@"GameProcessId"];
    [dict setValue:UserAnswer forKey:@"UserAnswer"];    
   	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_AuthenticateFacebookUser:(NSString *)UserName setEmail:(NSString *)Email setImageURL:(NSString *)ImageURL setDeviceID:(NSString *)DeviceID
{
    m_remotingCall.method = WEB_METHOD_AuthenticateFacebookUser;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setValue:UserName forKey:@"UserName"];
    [dict setValue:Email forKey:@"Email"];
    [dict setValue:ImageURL forKey:@"ImageURL"];
    [dict setValue:DeviceID forKey:@"DeviceID"];
   
      	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];

}

-(void)call_RandomSelection:(NSString *)MyID setUserName:(NSString *)UserName
{
    m_remotingCall.method = WEB_METHOD_RandomSelection;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:MyID forKey:@"MyID"];
    [dict setValue:UserName forKey:@"UserName"];
    [dict setValue:@"1" forKey:@"TotalCount"];
    m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_LogOut:(NSString *)UserId 
{
    m_remotingCall.method = WEB_METHOD_LogOut;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserId forKey:@"UserId"];   
    m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_HelloWorld
{
    m_remotingCall.method = WEB_METHOD_HelloWorld;	
   	m_remotingCall.arguments = nil;
	[m_remotingCall start];
}


-(void)call_GetChatHistoryByGameId:(NSString *)GameId setLastChatDateTime:(NSString *)LastChatDateTime
{
    m_remotingCall.method = WEB_METHOD_GetChatHistoryByGameId;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:GameId forKey:@"GameId"];
    [dict setValue:LastChatDateTime forKey:@"LastChatDateTime"];   
    m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];}

-(void)call_SendChatMessage:(NSString *)FromId setToId:(NSString *)ToId setGameId:(NSString *)GameId setMessage:(NSString *)Message setFromName:(NSString *)FromName
{
    m_remotingCall.method = WEB_METHOD_SendChatMessage;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:FromId forKey:@"FromId"];
    [dict setValue:ToId forKey:@"ToId"];
    [dict setValue:GameId forKey:@"GameId"];
    [dict setValue:Message forKey:@"Message"];
    [dict setValue:FromName forKey:@"FromName"];
    
    m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_CheckUserName:(NSString *)UserID setUserName:(NSString *)UserName
{
    m_remotingCall.method = WEB_METHOD_CheckUserName;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:UserID forKey:@"UserID"];
    [dict setValue:UserName forKey:@"UserName"];      
    m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

/*
-(void)call_GetInboxsearch:(NSString *)FacilityID setDoctor_ID:(NSString *)FacilityDoctor_ID setDateFrom:(NSString *)DateFrom setDateTo:(NSString *)DateTo setFirstName:(NSString *)PatientFirstName setLastName:(NSString *)PatientLastName setReportTitle:(NSString *)ReportTitle
{
	m_remotingCall.method = WEB_METHOD_GetInboxsearch;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:FacilityID forKey:@"FacilityID"];
	[dict setValue:FacilityDoctor_ID forKey:@"FacilityDoctor_ID"];
    [dict setValue:DateFrom forKey:@"DateFrom"];
	[dict setValue:DateTo forKey:@"DateTo"];
    [dict setValue:PatientFirstName forKey:@"PatientFirstName"];
	[dict setValue:PatientLastName forKey:@"PatientLastName"];
    [dict setValue:ReportTitle forKey:@"ReportTitle"];
    
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_GetListOfDoctors:(NSString *)FacilityID setEntityID:(NSString *)EntityID
{
	m_remotingCall.method = WEB_METHOD_GetListOfDoctors;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:FacilityID forKey:@"FacilityID"];
	[dict setValue:EntityID forKey:@"EntityID"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_GetReport:(NSString *)ReportRefID
{
	m_remotingCall.method = WEB_METHOD_GetReport;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:ReportRefID forKey:@"ReportRefID"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_GetReportImages:(NSString *)ReportRefID
{
	m_remotingCall.method = WEB_METHOD_GetReportImages;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:ReportRefID forKey:@"ReportRefID"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_Login:(NSString *)userId setPassword:(NSString *)password
{
	m_remotingCall.method = WEB_METHOD_Login;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:userId forKey:@"userId"];
	[dict setValue:password forKey:@"Password"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_Logout:(NSString *)logId
{
	m_remotingCall.method = WEB_METHOD_GetListOfDoctors;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:logId forKey:@"logId"];	
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}

-(void)call_SearchForDoctors:(NSString *)DoctorFirstname setDoctorSurname:(NSString *)DoctorSurname
{
    m_remotingCall.method = WEB_METHOD_SearchForDoctors;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:DoctorFirstname forKey:@"DoctorFirstname"];
	[dict setValue:DoctorSurname forKey:@"DoctorSurname"];
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}
-(void)call_SendForwardedReport:(NSString *)ReportRefID setDoctorID:(NSString *)DoctorID setFacilityDoctorID:(NSString *)FacilityDoctorID setComments:(NSString *)Comments
{
    m_remotingCall.method = WEB_METHOD_SendForwardedReport;
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	[dict setValue:ReportRefID forKey:@"ReportRefID"];
	[dict setValue:DoctorID forKey:@"DoctorID"];
    [dict setValue:FacilityDoctorID forKey:@"FacilityDoctorID"];
    [dict setValue:Comments forKey:@"Comments"];        
	m_remotingCall.arguments = [NSMutableDictionary dictionaryWithDictionary:dict];
	[m_remotingCall start];
}*/

#pragma mark -
#pragma mark SOAPRemotingCall Delegate methods

- (void)remotingCallDidFinishLoading:(SOAPRemotingCall *)remotingCall 
	receivedObject:(NSData *)object
{
	objc_msgSend(m_delegate, @selector(callerDidFinishLoading:receivedObject:), self, object);
}

- (void)remotingCall:(SOAPRemotingCall *)remotingCall didFailWithError:(NSError *)error
{

	objc_msgSend(m_delegate, @selector(caller:didFailWithError:), self, error);
}

@end