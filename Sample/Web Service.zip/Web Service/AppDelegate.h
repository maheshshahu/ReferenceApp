//
//  AppDelegate.h
//  speedRelate
//
//  Created by Krtya on 01/11/12.
//  Copyright (c) 2012 Krtya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SOAPMethods.h"
#import "EBPurchase.h"


@class ViewController;
@class Reachability;
@interface AppDelegate : UIResponder <UIApplicationDelegate,SOAPMethodsDelegate,EBPurchaseDelegate>
{
    
    SOAPMethods *soapMethods;
    NSString *strOpponent,*isNetConnect,*webMethodName ;
    NSMutableArray *arrdata,*arrMyFriendList,*arrFBFriendList,*arrChatData;
    Reachability* internetReach;
    
    UIImageView *imageView;
    UINavigationController *navController;

    EBPurchase* demoPurchase;
    BOOL isPurchased;
    NSString *strProductPriceDetail;
    
    BOOL alertShowing;
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;
@property (strong, nonatomic) NSString *strOpponent,*isNetConnect,*webMethodName;
@property (strong, nonatomic) NSMutableArray *arrdata,*arrMyFriendList,*arrFBFriendList,*arrChatData;

@property (retain, nonatomic) EBPurchase* demoPurchase;
@property (nonatomic) BOOL isPurchased;
@property (retain, nonatomic) NSString *strProductPriceDetail;

-(void)CheckDevice;
-(void)resetBadgeAppIcon;
-(void)purchaseProduct;
-(void)restorePurchase;

//extern  NSString *DATABASE_NAME;

@end
