//
//  SOAPRemotingCall.m
//  CocoaAMF
//
//  Created by Marc Bauer on 10.01.09.
//  Copyright 2009 nesiumdotcom. All rights reserved.
//

#import "SOAPRemotingCall.h"
#import "ConstantsAndMacros.h"
#import <objc/message.h>

@interface SOAPRemotingCall (Private)
- (NSString *)_nextResponseURI;
- (void)_cleanup;
@end


@implementation SOAPRemotingCall

@synthesize service=m_service, method=m_method, arguments=m_arguments, //B amfVersion=m_amfVersion, 
	delegate=m_delegate;

static uint32_t g_responseCount = 1;

#pragma mark -
#pragma mark Initialization & Deallocation

- (id)init
{
	if (self == [super init])
	{
		m_receivedData = nil;
		m_connection = nil;
		m_delegate = nil;
		m_isLoading = NO;
		//B m_amfVersion = kAMF3Version;
		m_error = nil;
		m_amfHeaders = nil;
		
		m_request = [[NSMutableURLRequest alloc] init];
		/*B old
		[m_request setHTTPMethod:@"POST"];
		[m_request setValue:@"application/x-amf" forHTTPHeaderField:@"Content-Type"];
		[m_request setValue:@"CocoaAMF" forHTTPHeaderField:@"User-Agent"];
		 */
		
		//BHC Start

		//BHC End
	}
	return self;
}

- (id)initWithURL:(NSURL *)url service:(NSString *)service method:(NSString *)method 
	arguments:(NSMutableDictionary *)arguments
{
	if (self == [self init])
	{
		self.URL = url;
		self.service = service;
		self.method = method;
		self.arguments = arguments;
	}
	return self;
}

+ (SOAPRemotingCall *)remotingCallWithURL:(NSURL *)url service:(NSString *)service 
	method:(NSString *)method arguments:(NSObject *)arguments
{
	SOAPRemotingCall *remotingCall = [[SOAPRemotingCall alloc] initWithURL:url service:service 
		method:method arguments:arguments];
	return [remotingCall autorelease];
}

- (void)dealloc
{
	[m_connection release];
	[m_request release];
	[m_service release];
	[m_method release];
	[m_arguments release];
	[m_error release];
	[m_amfHeaders release];
	[super dealloc];
}

#pragma mark -
#pragma mark Public methods

- (void)start
{
	if (m_isLoading)
	{
		return;
	}
	
	NSString *param = @"";
	
	if ([m_arguments isKindOfClass:[NSDictionary class]]) 
	{		
        //for(id theKey in m_arguments)
        for(id theKey in [[m_arguments allKeys] sortedArrayUsingSelector:@selector(compare:)])
		{
			NSString *anObject = [m_arguments objectForKey:theKey];
			param = [param stringByAppendingFormat:@"<%@>%@</%@>\n",theKey,anObject,theKey];
          
		}
	}
	m_request=[[NSMutableURLRequest alloc]init];
	NSString *soapMessage =  @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
		"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
		"<soap:Body>\n"
		//"<METHOD xmlns=\"http://tempuri.org/\">"
        "<METHOD xmlns=\"SOAPACTION\">"
		"PARAM"
		"</METHOD>\n"
		"</soap:Body>\n"
		"</soap:Envelope>\n";
	
	soapMessage = [soapMessage stringByReplacingOccurrencesOfString:@"SOAPACTION" withString:SOAP_ACTION];
	soapMessage = [soapMessage stringByReplacingOccurrencesOfString:@"METHOD" withString:m_method];
	soapMessage = [soapMessage stringByReplacingOccurrencesOfString:@"PARAM" withString:param];
		 
		
	//[m_request setURL: self.URL];
    [m_request setURL:[NSURL URLWithString:WEB_URL]];
    
    NSLog(@"soapMessage:%@",soapMessage);
	NSLog(@"SOAP_ACTION:%@/%@ URL::%@",SOAP_ACTION,m_method,WEB_URL);
  
    
	
	NSString *msgLength = [NSString stringWithFormat:@"%d", [soapMessage length]];
	[m_request addValue: msgLength forHTTPHeaderField:@"Content-Length"];
	[m_request setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
	[m_request addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[m_request addValue: [NSString stringWithFormat:@"%@/%@",SOAP_ACTION,m_method] forHTTPHeaderField:@"soapAction"];
	[m_request setHTTPMethod:@"POST"];
	
	/*UIAlertView *alertView1 = [[UIAlertView alloc] 
							   initWithTitle:@"Alert"
							   message:soapMessage 
							   delegate:self 
							   cancelButtonTitle:@"Ok" 
							   otherButtonTitles:nil];
	
	[alertView1 show];		*/
	
	m_error = nil;
	m_receivedData = [[NSMutableData alloc] init];
	m_connection = [[NSURLConnection alloc] initWithRequest:m_request delegate:self];
	m_isLoading = YES;
		
}

- (void)setURL:(NSURL *)url
{
	[m_request setURL:url];
}

- (NSURL *)URL
{
	return [m_request URL];
}

- (void)addValue:(NSString *)value forHTTPHeaderField:(NSString *)field
{
	[m_request addValue:value forHTTPHeaderField:field];
}

- (void)setValue:(NSString *)value forHTTPHeaderField:(NSString *)field
{
	[m_request setValue:value forHTTPHeaderField:field];
}

- (NSString *)valueForHTTPHeaderField:(NSString *)field
{
	return [m_request valueForHTTPHeaderField:field];
}

- (void)setValue:(NSObject *)value forAMFHeaderField:(NSString *)field 
	mustUnderstand:(BOOL)mustUnderstand
{
	if (m_amfHeaders == nil)
		m_amfHeaders = [[NSMutableDictionary alloc] init];
	//B [m_amfHeaders setValue:[AMFMessageHeader messageHeaderWithName:field data:value 
	//B	mustUnderstand:mustUnderstand] forKey:field];
}



#pragma mark -
#pragma mark Private methods

- (NSString *)_nextResponseURI
{
	return [NSString stringWithFormat:@"/%d", g_responseCount++];
}

- (void)_cleanup
{
	[m_connection release];
	m_connection = nil;
	[m_receivedData release];
	m_receivedData = nil;
	[m_error release];
	m_error = nil;
}



#pragma mark -
#pragma mark NSURLConnection Delegate methods

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{	
	
	if ([[[(NSHTTPURLResponse *)response allHeaderFields] objectForKey:@"Content-Type"] 
		rangeOfString:@"text/xml; charset=utf-8"].location == NSNotFound)
	{
		m_error = [[NSError errorWithDomain:kSOAPRemotingCallErrorDomain 
			code:kAMFInvalidResponseErrorCode userInfo:[NSDictionary dictionaryWithObject:
				[NSString stringWithFormat:@"The server returned no text/xml; charset=utf-8 data at URL %@.", 
					[[response URL] absoluteString]] forKey:NSLocalizedDescriptionKey]] retain];
	}
	else if ([(NSHTTPURLResponse *)response statusCode] != 200)
	{
		m_error = [[NSError errorWithDomain:kSOAPRemotingCallErrorDomain 
			code:kAMFServerErrorErrorCode userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
				[NSString stringWithFormat:@"The server returned status code %d at URL %@.", 
					[(NSHTTPURLResponse *)response statusCode], [[response URL] absoluteString]], 
				NSLocalizedDescriptionKey, [NSNumber numberWithInt:
					[(NSHTTPURLResponse *)response statusCode]], kAMFServerStatusCodeKey, nil]] retain];
	}
	
	if ([m_delegate respondsToSelector:@selector(remotingCall:didReceiveResponse:)])
	{
		objc_msgSend(m_delegate, @selector(remotingCall:didReceiveResponse:), self, response);
	}
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[m_receivedData appendData:data];
	if ([m_delegate respondsToSelector:@selector(remotingCall:didReceiveData:)])
	{
		objc_msgSend(m_delegate, @selector(remotingCall:didReceiveData:), self, data);
	}
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	
	//XMLReader *xmlReader = [[XMLReader alloc]init];
	//NSObject *object = [[NSMutableDictionary alloc] init];
	//object = [xmlReader objectWithData:m_receivedData];
	
	
	
	//NSString *text = @"";
//	NSString *theXML = [[NSString alloc] initWithBytes: [m_receivedData mutableBytes] length:[m_receivedData length] encoding:NSUTF8StringEncoding];
//	NSLog(@"klfbmvklf;gbk");
//	
//	NSLog (@"your xml is %@", theXML);

		
	
	
	if (!m_error && [m_receivedData length] == 0)
	{
		m_error = [[NSError errorWithDomain:kSOAPRemotingCallErrorDomain 
			code:kAMFInvalidResponseErrorCode userInfo:[NSDictionary dictionaryWithObject:
				@"The server returned zero bytes of data" forKey:NSLocalizedDescriptionKey]] retain];
	}

	if (m_error)
	{
		objc_msgSend(m_delegate, @selector(remotingCall:didFailWithError:), self, m_error);
	}
	else
	{
		
		//AMFActionMessage *message = [[AMFActionMessage alloc] initWithData:m_receivedData];
		//NSObject *data = [[message.bodies objectAtIndex:0] data];
		objc_msgSend(m_delegate, @selector(remotingCallDidFinishLoading:receivedObject:), 
					 self,m_receivedData);		 
			//self,[xmlReader objectWithData:m_receivedData]);
		
		
		
	}
	[self _cleanup];
	m_isLoading = NO;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	objc_msgSend(m_delegate, @selector(remotingCall:didFailWithError:), self, error);
	[self _cleanup];
	m_isLoading = NO;
}

- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request 
	redirectResponse:(NSURLResponse *)redirectResponse
{
	if ([m_delegate respondsToSelector:@selector(remotingCall:willSendRequest:redirectResponse:)])
	{
		return (NSURLRequest *)objc_msgSend(m_delegate, 
			@selector(remotingCall:willSendRequest:redirectResponse:), self, request, 
			redirectResponse);
	}
	return request;
}

@end