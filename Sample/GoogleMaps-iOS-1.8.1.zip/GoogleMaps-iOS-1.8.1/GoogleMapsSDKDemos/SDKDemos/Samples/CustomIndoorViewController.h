#import <UIKit/UIKit.h>

@interface CustomIndoorViewController : UIViewController
@end
