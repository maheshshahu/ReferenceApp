//
//  DynamicBehaviorsViewController.h
//  iOS7Sampler
//
//  Created by shuichi on 9/21/13.
//  Copyright (c) 2013 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DynamicBehaviorsViewController : UIViewController

@end
