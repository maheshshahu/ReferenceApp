#import <UIKit/UIKit.h>

@interface MyLocationViewController : UIViewController

@end
