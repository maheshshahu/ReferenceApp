//
//  XMLParser.m
//  LaneCove
//
//  Created by New MacMini on 21/07/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "XMLParser.h"
#import "AppDelegate.h"

@implementation XMLParser


- (XMLParser *) initXMLParser {
		
	appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [super init];
	return self;
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName 
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName 
	attributes:(NSDictionary *)attributeDict {
	
   // NSLog(@"elementName::%@",elementName);
    
	if([elementName isEqualToString:@"a:BuildingTypes"]) 
    {
		//Initialize the array.
		elementType=@"a:BuildingTypes";
       // if (appDelegate.arrayBuildingTypes == nil) 
        {
			//appDelegate.arrayBuildingTypes = [[NSMutableArray alloc] init];
		}
        
	}
  	else if([elementName isEqualToString:@"a:Cities"])
	{
		elementType=@"a:Cities";
       // if (appDelegate.arrayCities == nil) 
        {
			//appDelegate.arrayCities = [[NSMutableArray alloc] init];
		}        
        
		
	}
    else if([elementName isEqualToString:@"a:PropertyTypes"]) 
    {
       
        elementType=@"a:PropertyTypes";
       // if (appDelegate.arrayPropertyType == nil) 
        {
			//appDelegate.arrayPropertyType = [[NSMutableArray alloc] init];
		}
	}
  	else if([elementName isEqualToString:@"a:Finishes"])
	{ 
        elementType=@"a:Finishes";
       // if (appDelegate.arrayFinishes == nil) 
        {
        //appDelegate.arrayFinishes = [[NSMutableArray alloc] init];
        }
    }    
    else if([elementName isEqualToString:@"a:Defaults"])
    { 
        elementType=@"a:Defaults";
       // if (appDelegate.dictData == nil) 
        {
               // appDelegate.dictData = [[NSMutableDictionary alloc] init];
        }
    }
      
	    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string { 
	
	if(!currentElementValue) 
		currentElementValue = [[NSMutableString alloc] initWithString:string];
	else
		[currentElementValue appendString:string];
	//NSLog(@"currentElementValue name:%@",currentElementValue);
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName 
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	
    if([elementName isEqualToString:@"InitResult"] ||[elementName isEqualToString:@"InitResponse"]||[elementName isEqualToString:@"InitResult"]||[elementName isEqualToString:@"s:Body"]||[elementName isEqualToString:@"s:Envelope"] ) 
		return;
    
	//NSLog(@"Element name:%@ ,%@",elementName,currentElementValue);
	
	if([elementName isEqualToString:@"b:string"] && [elementType isEqualToString:@"a:BuildingTypes"])
	{	
		//NSLog(@"currentElementValue::%@",currentElementValue);
        //[appDelegate.arrayBuildingTypes addObject:currentElementValue];
		
	}
    else if([elementName isEqualToString:@"b:string"] && [elementType isEqualToString:@"a:Cities"])
	{	
		//NSLog(@"currentElementValue::%@",currentElementValue);
        //[appDelegate.arrayCities addObject:currentElementValue];
		
	}
    else if([elementName isEqualToString:@"b:string"] && [elementType isEqualToString:@"a:Finishes"])
	{	
		//NSLog(@"currentElementValue::%@",currentElementValue);
        //[appDelegate.arrayFinishes addObject:currentElementValue];
		
	}
    else if([elementName isEqualToString:@"b:string"] && [elementType isEqualToString:@"a:PropertyTypes"])
	{	
		//NSLog(@"currentElementValue::%@",currentElementValue);
        //[appDelegate.arrayPropertyType addObject:currentElementValue];
		
	}
    else if([elementType isEqualToString:@"a:Defaults"])
    {
        if (currentElementValue != nil ) {
            //[appDelegate.dictData setObject:currentElementValue forKey:elementName];
        }   

    }
  /*  else if([elementName isEqualToString:@"SubCategory"])
	{	
		[appDelegate.arraySubCategories addObject:dictSubCategories];
		[dictSubCategories release];
		dictSubCategories = nil;
	}
    else if([elementName isEqualToString:@"Business"])
	{	
		[appDelegate.arrayStores addObject:dictStores];
		[dictStores release];
		dictStores = nil;
	}
   	else if([elementName isEqualToString:@"CategoryID"] || [elementName isEqualToString:@"CategoryName"] || [elementName isEqualToString:@"CreatedDateTime"]|| [elementName isEqualToString:@"SubCategoryID"]|| [elementName isEqualToString:@"SubCategoryName"])
	{	
		if (currentElementValue != nil && dictCategories != nil) {
			[dictCategories setObject:currentElementValue forKey:elementName];
		}
        if (currentElementValue != nil && dictSubCategories != nil) {
			[dictSubCategories setObject:currentElementValue forKey:elementName];
		}
	}
  	else if([elementName isEqualToString:@"BusinessID"] || [elementName isEqualToString:@"Name"] || [elementName isEqualToString:@"SubCategoryID"]|| [elementName isEqualToString:@"Title"]|| [elementName isEqualToString:@"Address"] || [elementName isEqualToString:@"PhoneNo"] || [elementName isEqualToString:@"Email"] || [elementName isEqualToString:@"WebsiteURL"] || [elementName isEqualToString:@"FacebookURL"] || [elementName isEqualToString:@"TwitterURL"] || [elementName isEqualToString:@"iPhoneURL"] || [elementName isEqualToString:@"LogoURL"]|| [elementName isEqualToString:@"IsAccessible"])
   {
       if (currentElementValue != nil && dictStores != nil) {
           [dictStores setObject:currentElementValue forKey:elementName];
       }   
   }*/      
	
	[currentElementValue release];
	currentElementValue = nil;
}

- (void) dealloc {
	[elementType release];
	[currentElementValue release];
	[super dealloc];
}
@end
