#define APPLICATION_TITLE @"SpeedRelate"
#define WEB_URL @"http://173.193.184.99/SpeedRelatetest/SRWebService.asmx"

#define WEB_DOMAIN_URL @"http://173.193.184.99"
#define	SOAP_ACTION @"http://krtya.co.in/webservices/SpeedRelate"//@"http://tempuri.org"


//#define WEB_URL @"http://213.180.80.44/GabrielMessageSending.asmx"
//
//#define WEB_DOMAIN_URL @"http://213.180.80.44"
//#define	SOAP_ACTION @"http://tempuri.org"

//
#define WEB_METHOD_AddFriend @"AddFriend"
#define WEB_METHOD_AuthenticateUser @"AuthenticateUser"
#define WEB_METHOD_DeleteFriend @"DeleteFriend"
#define WEB_METHOD_EditProfile @"EditProfile"
#define WEB_METHOD_SearchUser @"SearchUser"
#define WEB_METHOD_UserRegister @"UserRegister"
#define WEB_METHOD_SendInvitation @"SendInvitation"
#define WEB_METHOD_ListMyFriend @"ListMyFriend"
#define WEB_METHOD_ListQuestion @"ListQuestion"
#define WEB_METHOD_CheckDevice @"CheckDevice"
#define WEB_METHOD_UpdateStatus @"UpdateStatus"
#define WEB_METHOD_DeleteGame @"DeleteGame"

#define WEB_METHOD_SetBadgeCount @"SetBadgeCount"

#define WEB_METHOD_UpdateScoreCard @"UpdateScoreCard"
#define WEB_METHOD_AuthenticateFacebookUser @"AuthenticateFacebookUser"
#define WEB_METHOD_RandomSelection @"RandomSelection"
#define WEB_METHOD_LogOut @"LogOut"

#define WEB_METHOD_GetChatHistoryByGameId @"GetChatHistoryByGameId"
#define WEB_METHOD_SendChatMessage @"SendChatMessage"

#define WEB_METHOD_CheckUserName @"CheckUserName"

#define WEB_METHOD_HelloWorld @"HelloWorld"

