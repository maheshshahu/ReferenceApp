//
//  AppDelegate.m
//  speedRelate
//
//  Created by Krtya on 01/11/12.
//  Copyright (c) 2012 Krtya. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "Reachability.h"
#import "SCFacebook.h"
#import "FirstViewController.h"
#import "MHImageCache.h"
#import "JSON.h"
#import "ChatViewController.h"

#import "MBProgressHUD.h"

#define SUB_PRODUCT_ID @"com.linnarsson.SpeedRelate.pro.item.n"

@implementation AppDelegate
@synthesize strOpponent,isNetConnect,webMethodName;
@synthesize arrdata;
@synthesize arrMyFriendList,arrFBFriendList,arrChatData;
@synthesize demoPurchase,isPurchased,strProductPriceDetail;

//NSString *DATABASE_NAME=@"speedRelateDB.sqlite";


- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    [[NSNotificationCenter defaultCenter] postNotificationName:OPEN_URL object:url];
    
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    
   /* UIAlertView *alertView;
    NSString *text = [[url host] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    alertView = [[UIAlertView alloc] initWithTitle:@"Text" message:text delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alertView show];
    [alertView release];*/
    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:OPEN_URL object:url];
    return YES;
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    
    //call Databasefile to copy
    // [self copyDatabaseIfNeeded];
    
    if (launchOptions != nil)
	{
		NSLog(@"launchOptions::%@",launchOptions);
        NSDictionary* dictionary = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
		if (dictionary != nil)
		{
			//app not running
            NSLog(@"Launched from push notification: %@", dictionary);
            /*UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"didFinishLaunchingWithOptions"
             message:[dictionary description]
             delegate:nil
             cancelButtonTitle:@"Cancel"
             otherButtonTitles:nil];
             [av show];
             [av release];*/
            //[self checkMessage];
             [self resetBadgeAppIcon];
		}
	}
    
    self.arrMyFriendList=[[NSMutableArray alloc]init];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"FaceBookFriends"]) {
        self.arrFBFriendList =[[NSUserDefaults standardUserDefaults] valueForKey:@"FaceBookFriends"] ;
    }else
    {
        self.arrFBFriendList =[[NSMutableArray alloc]init];
    }
    
    [self registerForRemoteNotifications];
    
    
    
    
    // Observe the kNetworkReachabilityChangedNotification. When that notification is posted, the
    // method "reachabilityChanged" will be called.
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(reachabilityChanged:) name: kReachabilityChangedNotification object: nil];
    internetReach = [[Reachability reachabilityForInternetConnection] retain];
	[internetReach startNotifier];
	[self updateInterfaceWithReachability: internetReach];
    
    
    self.demoPurchase = [[EBPurchase alloc] init];
    self.demoPurchase.delegate = self;
    
    
    isPurchased =  NO; // default.
    if (![self.demoPurchase requestProduct:SUB_PRODUCT_ID])
    {
        // Returned NO, so notify user that In-App Purchase is Disabled in their Settings.
        // [buyButton setTitle:@"Purchase Disabled in Settings" forState:UIControlStateNormal];
        
    }

    
    
    
    if(![[NSUserDefaults standardUserDefaults] valueForKey:@"UserName"])
	{
        // loginView=[[[LoginViewController alloc]init]autorelease];
        // navController=[[UINavigationController alloc]initWithRootViewController:loginView];
        
        FirstViewController *firstViewController =[[[FirstViewController alloc]init]autorelease];
        navController=[[UINavigationController alloc]initWithRootViewController:firstViewController];
        navController.navigationBarHidden=YES;
        
        /*RegisterViewController *registerViewController=[[[RegisterViewController alloc]init]autorelease];
         navController=[[UINavigationController alloc]initWithRootViewController:registerViewController];*/
    }else
    {
        self.viewController = [[ViewController alloc] init];//WithNibName:@"ViewController" bundle:nil] autorelease];
        navController=[[UINavigationController alloc]initWithRootViewController:self.viewController];
        
        [self CheckDevice];
        
        
    }
    
    if(![[NSUserDefaults standardUserDefaults] valueForKey:@"LanguageId"])
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"LanguageId"];
    }
    
    //navController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    //[navController.navigationBar setTintColor:[UIColor colorWithRed:90.0f/255.0f green:210.0f/255.0f blue:260.0f/255.0f alpha:1.0]];
      [navController.navigationBar setTintColor:[UIColor colorWithRed:210.0f/255.0f green:0.0f/255.0f blue:00.0f/255.0f alpha:1.0]];
      [[UIApplication sharedApplication] setStatusBarStyle: UIStatusBarStyleBlackOpaque];
    
    self.window.rootViewController = navController;
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (screenBounds.size.height == 568) {
        // code for 4-inch screen
         self.window.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"background_640x1136.png"]];
    } else {
        // code for 3.5-inch screen
         self.window.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"background_320x480.png"]];
    }
    
   
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    [self resetBadgeAppIcon];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    [self clearLocalQueueForLocalNotifications];
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark - Reachbility
- (void) setReachability: (Reachability*) curReach
{
    NSLog(@"curReach::%@",curReach);
    NetworkStatus netStatus = [curReach currentReachabilityStatus];
    BOOL connectionRequired= [curReach connectionRequired];
    NSString* statusString= @"";
    self.isNetConnect=@"YES";
    switch (netStatus)
    {
        case NotReachable:
        {
            statusString = @"Access Not Available";
            //imageView.image = [UIImage imageNamed: @"stop-32.png"] ;
            //Minor interface detail- connectionRequired may return yes, even when the host is unreachable.  We cover that up here...
            connectionRequired= NO;
            self.isNetConnect=@"NO";
            break;
        }
            
        case ReachableViaWWAN:
        {
            statusString = @"Reachable WWAN";
            //imageView.image = [UIImage imageNamed: @"WWAN5.png"];
            // self.isNetConnect=@"YES";
            break;
        }
        case ReachableViaWiFi:
        {
            statusString= @"Reachable WiFi";
            // self.isNetConnect=@"YES";
            //imageView.image = [UIImage imageNamed: @"Airport.png"];
            break;
        }
    }
    if(connectionRequired)
    {
        statusString= [NSString stringWithFormat: @"%@, Connection Required", statusString];
    }
    //textField.text= statusString;
    NSLog(@"connecton String::%@",statusString);
    
    if (![self.isNetConnect boolValue])
    {
        UIAlertView *alertView1 = [[UIAlertView alloc]
                                   initWithTitle:@"Connection Error"
                                   message:@"Could not connect to the SpeedRelate server.Make sure you have an active internet connection."
                                   delegate:nil
                                   cancelButtonTitle:@"Ok"
                                   otherButtonTitles:nil];
        [alertView1 show];
        [alertView1 release];
        
    }
}

- (void) updateInterfaceWithReachability: (Reachability*) curReach
{
    
	if(curReach == internetReach)
	{
		[self setReachability: curReach];
	}
    
}

//Called by Reachability whenever status changes.
- (void) reachabilityChanged: (NSNotification* )note
{
	Reachability* curReach = [note object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
	[self updateInterfaceWithReachability: curReach];
}


#pragma mark -

-(void)CheckDevice
{
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"UserId"])
    {
        imageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"main_bg.png"]];
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (screenBounds.size.height == 568) {
            // code for 4-inch screen
                    imageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"background_640x1136.png"]];
        } else {
            // code for 3.5-inch screen
                    imageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"background_320x480.png"]];
        }
        
        [[ self.viewController view] addSubview:imageView];
        [[ self.viewController view] bringSubviewToFront:imageView];
        
        
        NSString *strDeviceID;
        
#if TARGET_IPHONE_SIMULATOR
        {
            //Simulator
            strDeviceID=@"1234567890";
        }
#else
        {
            // Device
            strDeviceID= [[NSUserDefaults  standardUserDefaults] valueForKey:@"deviceToken"];
        }
#endif
        
        
        soapMethods = [[SOAPMethods alloc] init];
        soapMethods.delegate = self;
        
        
        self.webMethodName=@"CheckDevice";
        [soapMethods call_CheckDevice:[[NSUserDefaults standardUserDefaults] valueForKey:@"UserId"] setDeviceID:strDeviceID ];
    }
    
    
    
    
}

-(void)resetBadgeAppIcon
{
    
    NSString *strDeviceID;
    
#if TARGET_IPHONE_SIMULATOR
    {
        //Simulator
        strDeviceID=@"1234567890";
    }
#else
    {
        // Device
        strDeviceID= [NSString stringWithFormat:@"%@", [[NSUserDefaults  standardUserDefaults] valueForKey:@"deviceToken"]];
    }
#endif
        
        soapMethods = [[SOAPMethods alloc] init];
        soapMethods.delegate = self;
        
        self.webMethodName=@"SetBadgeCount";
        [soapMethods call_SetBadgeCount:@"0" setDeviceID:strDeviceID ];
             
    
}


-(void)GetChatHistoryByGameId:(NSString *)GameId
{
    
    NSPredicate *predicate;
    predicate = [NSPredicate predicateWithFormat:@"GameId == %d",[GameId intValue]];
    NSMutableArray *arrTemp = [[NSMutableArray alloc]initWithArray:[self.arrChatData  filteredArrayUsingPredicate:predicate]];
       
        
    if ([arrTemp count]>0)
    {
        NSDictionary *dict = [arrTemp lastObject];
        
        if ([dict valueForKey:@"Created"])
        {
            soapMethods = [[SOAPMethods alloc] init];
            soapMethods.delegate = self;
                        
            self.webMethodName=@"GetChatHistoryByGameId";
            [soapMethods call_GetChatHistoryByGameId:GameId setLastChatDateTime:[dict valueForKey:@"Created"]];
        }      
    }
        
}

- (void)clearLocalQueueForLocalNotifications
{
    NSLog(@"clear Local Queue For Local Notifications");
    UIApplication *app = [UIApplication sharedApplication];
	NSArray *oldNotifications = [app scheduledLocalNotifications];
	
	// Clear out the old notification before scheduling a new one.
	if (0 < [oldNotifications count])
    {
        [app cancelAllLocalNotifications];
	}
    
    // [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(callServices) object:nil];
}


-(void)purchaseProduct
{
    // First, ensure that the SKProduct that was requested by
    // the EBPurchase requestProduct method in the viewWillAppear
    // event is valid before trying to purchase it.
    
    
    if (self.demoPurchase.validProduct != nil)
    {
        // Then, call the purchase method.
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.window animated:YES];
        hud.mode = MBProgressHUDModeIndeterminate;
        hud.labelText = @"Loadding";
        
        if (![self.demoPurchase purchaseProduct:self.demoPurchase.validProduct])
        {
            // Returned NO, so notify user that In-App Purchase is Disabled in their Settings.
            UIAlertView *settingsAlert = [[UIAlertView alloc] initWithTitle:@"Allow Purchases" message:@"You must first enable In-App Purchase in your iOS Settings before making this purchase." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [settingsAlert show];
            [settingsAlert release];
            [MBProgressHUD hideHUDForView:self.window animated:YES];
        }
    }
}

-(void)restorePurchase
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.window animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.labelText = @"Loadding";
    // Restore a customer's previous non-consumable or subscription In-App Purchase.
    // Required if a user reinstalled app on same device or another device.
    
    // Call restore method.
    if (![self.demoPurchase restorePurchase])
    {
        // Returned NO, so notify user that In-App Purchase is Disabled in their Settings.
        UIAlertView *settingsAlert = [[UIAlertView alloc] initWithTitle:@"Allow Purchases" message:@"You must first enable In-App Purchase in your iOS Settings before restoring a previous purchase." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [settingsAlert show];
        [settingsAlert release];
    }
}




#pragma mark -
#pragma mark -
#pragma mark EBPurchaseDelegate Methods

-(void) requestedProduct:(EBPurchase*)ebp identifier:(NSString*)productId name:(NSString*)productName price:(NSString*)productPrice description:(NSString*)productDescription
{
    NSLog(@"ViewController requestedProduct");
    NSLog(@"%@ %@ %@ %@",productId,productName,productPrice,productDescription);
    //[MBProgressHUD hideHUDForView:self.view animated:YES];
    
    if (productPrice != nil)
    {
        // Product is available, so update button title with price.
        
        //[buyButton setTitle:[@"Buy Game Levels Pack " stringByAppendingString:productPrice] forState:UIControlStateNormal];
        //buyButton.enabled = YES; // Enable buy button.
        self.strProductPriceDetail=[@"Upgrade to Premium for" stringByAppendingString:productPrice];
        
       // [self SetTableviewCellBackground:[NSIndexPath indexPathForRow:0 inSection:3] Disable:NO setLblText:[@"Upgrade to Premium for" stringByAppendingString:productPrice] ];
        
        
    } else {
        // Product is NOT available in the App Store, so notify user.
        
        //buyButton.enabled = NO; // Ensure buy button stays disabled.
        //[buyButton setTitle:@"Buy Game Levels Pack" forState:UIControlStateNormal];
        self.strProductPriceDetail=@"Upgrade to Premium for 15 kr";
        
        /*UIAlertView *unavailAlert = [[UIAlertView alloc] initWithTitle:@"Not Available" message:@"This In-App Purchase item is not available in the App Store at this time. Please try again later." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
         [unavailAlert show];
         [unavailAlert release];*/
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ChangeProductPrice" object:nil userInfo:nil];
}

-(void) successfulPurchase:(EBPurchase*)ebp restored:(bool)isRestore identifier:(NSString*)productId receipt:(NSData*)transactionReceipt
{
    NSLog(@"ViewController successfulPurchase");
    
    // Purchase or Restore request was successful, so...
    // 1 - Unlock the purchased content for your new customer!
    // 2 - Notify the user that the transaction was successful.
    [MBProgressHUD hideHUDForView:self.window animated:YES];
    
    //if (!isPurchased)
    {
        // If paid status has not yet changed, then do so now. Checking
        // isPurchased boolean ensures user is only shown Thank You message
        // once even if multiple transaction receipts are successfully
        // processed (such as past subscription renewals).
        
        isPurchased = YES;
        
        //-------------------------------------
        
        // 1 - Unlock the purchased content and update the app's stored settings.
        
        //-------------------------------------
        
        // 2 - Notify the user that the transaction was successful.
        
        NSString *alertMessage;
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"IsDisplayAD"];
        
        if (isRestore) {
            // This was a Restore request.
            alertMessage = @"Your purchase was restored ";
            //[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"IsDisplayAD"];
            
            //[self SetTableviewCellBackground:[NSIndexPath indexPathForRow:0 inSection:3] Disable:NO setLblText:@"" ];
            
        } else {
            // This was a Purchase request.
            alertMessage = @"Your purchase was successful ";
            
            
           // [self SetTableviewCellBackground:[NSIndexPath indexPathForRow:0 inSection:3] Disable:YES setLblText:@"" ];
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"successfulPurchase" object:nil userInfo:nil];
        
        if (!alertShowing) {
            alertShowing =YES;
        
        UIAlertView *updatedAlert = [[UIAlertView alloc] initWithTitle:@"Thank You!" message:alertMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            updatedAlert.tag=100;
        [updatedAlert show];
        [updatedAlert release];
        }
    }
}

-(void) failedPurchase:(EBPurchase*)ebp error:(NSInteger)errorCode message:(NSString*)errorMessage
{
    [MBProgressHUD hideHUDForView:self.window animated:YES];
    NSLog(@"ViewController failedPurchase");
    NSLog(@"errorMessage ::%@ ",errorMessage);
    
    // Purchase or Restore request failed or was cancelled, so notify the user.
    /*if (errorCode!=2)
     {
     UIAlertView *failedAlert = [[UIAlertView alloc] initWithTitle:@"Purchase Stopped" message:@"Either you cancelled the request or Apple reported a transaction error. Please try again later, or contact the app's customer support for assistance." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
     [failedAlert show];
     [failedAlert release];
     }*/
    
}

-(void) incompleteRestore:(EBPurchase*)ebp
{
    [MBProgressHUD hideHUDForView:self.window animated:YES];
    NSLog(@"ViewController incompleteRestore");
    
    // Restore queue did not include any transactions, so either the user has not yet made a purchase
    // or the user's prior purchase is unavailable, so notify user to make a purchase within the app.
    // If the user previously purchased the item, they will NOT be re-charged again, but it should
    // restore their purchase.
    
    UIAlertView *restoreAlert = [[UIAlertView alloc] initWithTitle:@"Restore Issue" message:@"A prior purchase transaction could not be found. To restore the purchased product, tap the Buy button. Paid customers will NOT be charged again, but the purchase will be restored." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [restoreAlert show];
    [restoreAlert release];
}

-(void) failedRestore:(EBPurchase*)ebp error:(NSInteger)errorCode message:(NSString*)errorMessage
{
    [MBProgressHUD hideHUDForView:self.window animated:YES];
    NSLog(@"ViewController failedRestore");
    
    // Restore request failed or was cancelled, so notify the user.
    
    /* UIAlertView *failedAlert = [[UIAlertView alloc] initWithTitle:@"Restore Stopped" message:@"Either you cancelled the request or your prior purchase could not be restored. Please try again later, or contact the app's customer support for assistance." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
     [failedAlert show];
     [failedAlert release];*/
}


#pragma mark -
#pragma mark - alertview Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if ([alertView tag]==100)
    {
        alertShowing = NO;
    }
    
}
#pragma mark -

#pragma mark -delegate Method

- (void)callerDidFinishLoading:(SOAPMethods *)caller receivedObject:(NSData *)object
{
	NSString *theXML1 = [[NSString alloc] initWithBytes: [object bytes] length:[object length] encoding:NSUTF8StringEncoding];
   	
	NSLog(@"theXML1::%@",theXML1);
    
    
    if ([self.webMethodName isEqualToString:@"CheckDevice"])
    {        
        
        theXML1 = [theXML1 stringByReplacingOccurrencesOfString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><CheckDeviceResponse xmlns=\"http://krtya.co.in/webservices/SpeedRelate\"><CheckDeviceResult>"   withString: @""];
        
        theXML1 = [theXML1 stringByReplacingOccurrencesOfString:
                   @"</CheckDeviceResult></CheckDeviceResponse></soap:Body></soap:Envelope>"   withString:@""];
        
        
        if ([theXML1 intValue]==1)
        {
            navController.navigationBar.hidden = NO;
        }else if ([theXML1 intValue]==0)
        {
            navController.navigationBar.hidden = YES;
            /*navController.navigationItem.backBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:nil action:nil] autorelease];
            LoginViewController *loginView=[[LoginViewController alloc]init];
            loginView.isBackDisplay = TRUE;
            [navController pushViewController:loginView animated:NO];*/
            
            FirstViewController *firstViewController =[[[FirstViewController alloc]init]autorelease];
            [navController pushViewController:firstViewController animated:NO];
            
        }
        
        [UIView transitionWithView:self.window duration:1.0f options:UIViewAnimationOptionTransitionNone animations:^(void){imageView.alpha=0.0f;} completion:^(BOOL finished){[imageView removeFromSuperview];}];
        
    }else if ([self.webMethodName isEqualToString:@"SetBadgeCount"])
    {
        
    }else if([self.webMethodName isEqualToString:@"GetChatHistoryByGameId"])
    {
        theXML1 = [theXML1 stringByReplacingOccurrencesOfString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetChatHistoryByGameIdResponse xmlns=\"http://krtya.co.in/webservices/SpeedRelate\"><GetChatHistoryByGameIdResult>"   withString: @""];
        
        theXML1 = [theXML1 stringByReplacingOccurrencesOfString:
                   @"</GetChatHistoryByGameIdResult></GetChatHistoryByGameIdResponse></soap:Body></soap:Envelope>"   withString:@""];
        
//        UIAlertView *alertView1 = [[UIAlertView alloc]
//                                   initWithTitle:@"GetChatHistoryByGameId"
//                                   message:theXML1
//                                   delegate:nil
//                                   cancelButtonTitle:@"Ok"
//                                   otherButtonTitles:nil];
//        [alertView1 show];
//        [alertView1 release];
        
      /*  UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"callerDidFinishLoading"
                                                     message:theXML1
                                                    delegate:nil
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:nil];
        [av show];
        [av release];*/
        
        
        NSMutableArray *arrChatHistory = [theXML1 JSONValue];
        if ([arrChatHistory count]>0)
        {
            NSMutableDictionary *dict = [arrChatHistory lastObject];
                        
            [self.arrChatData addObjectsFromArray:arrChatHistory];
            
           /* UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"arrChatData"
                                                         message:[self.arrChatData description]
                                                        delegate:nil
                                               cancelButtonTitle:@"Cancel"
                                               otherButtonTitles:nil];
            [av show];
            [av release];
**/
            NSPredicate *predicate;
            predicate = [NSPredicate predicateWithFormat:@"GameId == %d",[[dict valueForKey:@"GameId"]intValue]];            
            ChatViewController *chatView =[[ChatViewController alloc]init];           
            [chatView loadViewAtFirst:[[NSMutableArray alloc]initWithArray:[self.arrChatData  filteredArrayUsingPredicate:predicate]]];
        }
    }
        
    [caller release];
    // [soapMethods release];
    
    
    
    /**/
    
	
}


- (void)caller:(SOAPMethods *)caller didFailWithError:(NSError *)error1
{
	NSLog(@"error1::%@",[NSString stringWithFormat: @"%@",[error1 localizedDescription]]);
	
    
	/*UIAlertView *alertTest = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat: @"%@",[error1 localizedDescription]] delegate: self cancelButtonTitle: @"Ok" otherButtonTitles:nil];
    [alertTest show];
    [alertTest release];
    [caller release];*/
	
    
    //soapMethods = [[SOAPMethods alloc] init];
    //soapMethods.delegate = self;
    //[soapMethods call_SaveMyContact:deviceId setContacts:jsonString];
}

#pragma mark -


#pragma mark - RemoteNotifications

- (void)registerForRemoteNotifications
{
	[[UIApplication sharedApplication] registerForRemoteNotificationTypes:
	 
	 UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound];
}

- (void)unregisterForRemoteNotifications
{
	//    call this to test the feedback service
	
	[[UIApplication sharedApplication] unregisterForRemoteNotifications];
}


- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
	NSLog(@"Failed to register for Push Notifications : %@", [error localizedDescription]);
    /*UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"didFailToRegisterForRemoteNotificationsWithError"
     message:[error localizedDescription]
     delegate:nil
     cancelButtonTitle:@"Cancel"
     otherButtonTitles:nil];
     [av show];
     [av release];*/
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
	NSLog(@"My token is: %@", deviceToken);
	
	NSString *content = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
	content = [content stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	[[NSUserDefaults standardUserDefaults] setObject:content forKey:@"deviceToken"];
	
    
    /*UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"didRegisterForRemoteNotificationsWithDeviceToken"
     message:content
     delegate:nil
     cancelButtonTitle:@"Cancel"
     otherButtonTitles:nil];
     
     [av show];
     [av release];*/
	
    
}


- (void)application:(UIApplication*)application didReceiveRemoteNotification:(NSDictionary*)userInfo
{
	// This method is invoked when the app is running and a push notification
	// is received. If the app was suspended in the background, it is woken up
	// and this method is invoked as well. We add the new message to the data
	NSLog(@"Received notification: %@", userInfo);
    //isRNCall=YES;
    
//    UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"didReceiveRemoteNotification"
//                                                 message:[userInfo description]
//                                                delegate:nil
//                                       cancelButtonTitle:@"Cancel"
//                                       otherButtonTitles:nil];
//    [av show];
//    [av release];
    
    id var =[[userInfo objectForKey:@"aps"] objectForKey: @"alert"] ;
    
    if ([var isKindOfClass:[NSDictionary class]])
    {
        NSMutableArray *arr = [[[userInfo objectForKey:@"aps"] objectForKey: @"alert"] valueForKey:@"loc-args"];
        
        if (arr)
        {
            //[self GetChatHistoryByGameId:[arr objectAtIndex:0]];
            
            UIViewController *currentVC = navController.visibleViewController;
            if (![currentVC isMemberOfClass:[ChatViewController class]])
            {
              
                NSArray *joins = [[[[userInfo objectForKey:@"aps"] objectForKey: @"alert"] valueForKey:@"body"] componentsSeparatedByString:@"-"];
                
                UIAlertView *av = [[UIAlertView alloc] initWithTitle:@""
                                                              message:[NSString stringWithFormat:@"You got a new message from %@",[joins objectAtIndex:1]]
                                                             delegate:nil
                                                    cancelButtonTitle:@"Cancel"
                                                    otherButtonTitles:nil];
                [av show];
                [av release];
            }
            
        }
    }
    

    
    
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateInactive)
    {
        //----- APPLICATION WAS IN BACKGROUND - USER HAS SEEN NOTIFICATION AND PRESSED THE ACTION BUTTON -----
        NSLog(@"Local noticiation - App was in background and user pressed action button");
        
        
    }
    else
    {
        //----- APPLICATION IS IN FOREGROUND - USER HAS NOT BEEN PRESENTED WITH THE NOTIFICATION -----
        NSLog(@"Local noticiation - App was in foreground");
        
        /*UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"didReceiveRemoteNotification"
         message:[userInfo objectForKey:@"alert"]
         delegate:nil
         cancelButtonTitle:@"Cancel"
         otherButtonTitles:nil];
         [av show];
         [av release];*/
        
        //[self checkMessage];
        //[self resetBadgeAppIcon];
               
    }
    
    
    
    
    

    
    
    /*NSString *message = nil;
     id alert = [userInfo objectForKey:@"alert"];
     if ([alert isKindOfClass:[NSString class]]) {
     message = alert;
     } else if ([alert isKindOfClass:[NSDictionary class]]) {
     message = [alert objectForKey:@"body"];
     }*/
    
    
    
    // [self checkMessage];
    
}


#pragma mark -
- (void)dealloc
{
    [_window release];
    [_viewController release];
    
    [super dealloc];
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication*)application
{
	[[MHImageCache sharedInstance] flushMemory];
}

#pragma mark -
#pragma mark Sqlite methods

//- (void) copyDatabaseIfNeeded {
//
//	//Using NSFileManager we can perform many file system operations.
//	NSFileManager *fileManager = [NSFileManager defaultManager];
//	NSError *error;
//	NSString *dbPath = [self getDBPath];
//	BOOL success = [fileManager fileExistsAtPath:dbPath];
//
//	if(!success) {
//
//		NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:DATABASE_NAME];
//		success = [fileManager copyItemAtPath:defaultDBPath toPath:dbPath error:&error];
//
//		if (!success)
//			NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
//	}
//}
//
//- (NSString *) getDBPath {
//
//	//Search for standard documents using NSSearchPathForDirectoriesInDomains
//	//First Param = Searching the documents directory
//	//Second Param = Searching the Users directory and not the System
//	//Expand any tildes and identify home directories.
//	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
//	NSString *documentsDir = [paths objectAtIndex:0];
//	return [documentsDir stringByAppendingPathComponent:DATABASE_NAME];
//}

#pragma mark
@end
