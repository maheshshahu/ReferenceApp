//
//  SOAPMethods.h
//  CocoaAMF-iPhone
//
//  Created by Marc Bauer on 11.01.09.
//  Copyright 2009 nesiumdotcom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SOAPRemotingCall.h"

@protocol SOAPMethodsDelegate;

@interface SOAPMethods : NSObject <SOAPRemotingCallDelegate>
{
	SOAPRemotingCall *m_remotingCall;
	NSObject <SOAPMethodsDelegate> *m_delegate;
}

@property (nonatomic, assign) NSObject <SOAPMethodsDelegate> *delegate;

-(void)call_HelloWorld;
-(void)call_SearchUser:(NSString *)UserName;
-(void)call_AddFriend:(NSString *)UserName setFriendName:(NSString *)FriendName;
-(void)call_ListMyFriend:(NSString *)UserID ;
-(void)call_ListQuestion:(NSString *)GameId setReset:(NSString *)Reset;
-(void)call_DeleteFriend:(NSString *)UserName setFriendName:(NSString *)FriendName;
-(void)call_AuthenticateUser:(NSString *)UserName setEmail:(NSString *)Email setPassword:(NSString *)Password setDeviceID:(NSString *)DeviceID ;
-(void)call_EditProfile:(NSString *)UserId setUserName:(NSString *)UserName setEmail:(NSString *)Email setPassword:(NSString *)Password setImageData:(NSString *)ImageData;  
-(void)call_UserRegister:(NSString *)UserName setEmail:(NSString *)Email setDeviceID:(NSString *)DeviceID;
-(void)call_SendInvitation:(NSString *)UserName setFriendName:(NSString *)FriendName setLanguageID:(NSString *)LanguageID;
-(void)call_CheckDevice:(NSString *)UserId setDeviceID:(NSString *)DeviceID;

-(void)call_SetBadgeCount:(NSString *)BadgeCount setDeviceID:(NSString *)DeviceID;

-(void)call_UpdateStatus:(NSString *)GameId;
-(void)call_DeleteGame:(NSString *)GameId setUserID:(NSString *)UserID;
-(void)call_UpdateScoreCard:(NSString *)UserName setGameId:(NSString *)GameId setScore:(NSString *)Score setGameProcessId:(NSString *)GameProcessId setUserAnswer:(NSString *)UserAnswer;
-(void)call_AuthenticateFacebookUser:(NSString *)UserName setEmail:(NSString *)Email setImageURL:(NSString *)ImageURL setDeviceID:(NSString *)DeviceID;

-(void)call_RandomSelection:(NSString *)MyID setUserName:(NSString *)UserName;
-(void)call_LogOut:(NSString *)UserId;

-(void)call_GetChatHistoryByGameId:(NSString *)GameId setLastChatDateTime:(NSString *)LastChatDateTime;
-(void)call_SendChatMessage:(NSString *)FromId setToId:(NSString *)ToId setGameId:(NSString *)GameId setMessage:(NSString *)Message setFromName:(NSString *)FromName;

-(void)call_CheckUserName:(NSString *)UserID setUserName:(NSString *)UserName;

@end

@protocol SOAPMethodsDelegate
- (void)callerDidFinishLoading:(SOAPMethods *)caller receivedObject:(NSData *)object;
- (void)caller:(SOAPMethods *)caller didFailWithError:(NSError *)error;

@end