//
//  XMLParser.h
//  LaneCove
//
//  Created by New MacMini on 21/07/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"

@interface XMLParser : NSObject<NSXMLParserDelegate>
{
    AppDelegate *appDelegate;
    /*NSMutableArray *arrayCities;
    NSMutableArray *arrayBuildingTypes;    
    NSMutableArray *arrayFinishes ;        
    NSMutableArray *arrayPropertyType;
    NSMutableString *strFloorArea; 
    NSMutableString *strLevels;
    NSMutableString *strMaxFloorArea;
    NSMutableString *strMaxLevels;
    NSMutableString *strMinFloorArea;*/
     NSMutableString *currentElementValue;
     NSString  *elementType; 
}
//@property (nonatomic,retain) BMTQSAppDelegate *appDelegate;
/*@property (nonatomic, retain)  NSMutableArray *arrayCities;      
@property (nonatomic, retain)  NSMutableArray *arrayBuildingTypes;
@property (nonatomic, retain)  NSMutableArray *arrayFinishes;
@property (nonatomic, retain)  NSMutableArray *arrayPropertyType;*/

@end
