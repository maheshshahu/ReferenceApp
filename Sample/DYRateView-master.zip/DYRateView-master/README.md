DYRateView
==========

A custom iOS rate view control similar to the one used in Apple's App Store app.  

You can find a tutorial of DYRateView on my blog: http://iappexperience.com/post/23227218867/dyrateview-a-simple-yet-powerful-rating-control-for.    
    

![picture](http://f.cl.ly/items/2D2R152W1z3T0O033f0G/DYRateView---readonly.png "Readonly view")

![picture](http://f.cl.ly/items/1d291U2w423y3t2L0B02/DYRateView---editable.png "Editable view")
