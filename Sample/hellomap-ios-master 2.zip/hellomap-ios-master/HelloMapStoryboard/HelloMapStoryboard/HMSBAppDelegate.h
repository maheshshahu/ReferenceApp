//
//  HMSBAppDelegate.h
//  HelloMapStoryboard
//
//  Created by Luke Mahe on 6/4/13.
//  Copyright (c) 2013 Example. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMSBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
