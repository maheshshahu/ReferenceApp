#import "HMViewController.h"
#import <GoogleMaps/GoogleMaps.h>

static NSString * const TitleKey = @"title";
static NSString * const InfoKey = @"info";
static NSString * const LatitudeKey = @"latitude";
static NSString * const LongitudeKey = @"longitude";


@interface HMViewController () {
  GMSMapView *mapView_;
}

@end

@implementation HMViewController

- (void)viewDidLoad {
  [super viewDidLoad];

  // Position the camera at 0,0 and zoom level 1.
  GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:48.8584
                                                          longitude:2.2946
                                                               zoom:12];

  // Create the GMSMapView with the camera position.
  mapView_ = [GMSMapView mapWithFrame:CGRectZero camera:camera];
    
      [self addMarkersToMap];
    //[self addCircleToMap];
    
   

  // Set the controller view to be the MapView. 
  self.view = mapView_;
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
}

- (void)addMarkersToMap {
    
    NSArray *markerInfos = @[
                             @{
                                 TitleKey: @"Eiffel Tower",
                                 InfoKey: @"A wrought-iron structure erected in Paris in 1889. With a height of 984 feet (300 m), it was the tallest man-made structure for many years.",
                                 LatitudeKey: @48.8584,
                                 LongitudeKey: @2.2946
                                 },
                             @{
                                 TitleKey: @"Centre Georges Pompidou",
                                 InfoKey: @"Centre Georges Pompidou is a complex in the Beaubourg area of the 4th arrondissement of Paris. It was designed in the style of high-tech architecture.",
                                 LatitudeKey: @48.8607,
                                 LongitudeKey: @2.3524
                                 },
                             @{
                                 TitleKey: @"The Louvre",
                                 InfoKey: @"The principal museum and art gallery of France, in Paris.",
                                 LatitudeKey: @48.8609,
                                 LongitudeKey: @2.3363
                                 },
                             @{
                                 TitleKey: @"Arc de Triomphe",
                                 InfoKey: @"A ceremonial arch standing at the top of the Champs Élysées in Paris.",
                                 LatitudeKey: @48.8738,
                                 LongitudeKey: @2.2950
                                 },
                             @{
                                 TitleKey: @"Notre Dame",
                                 InfoKey: @"A Gothic cathedral in Paris, dedicated to the Virgin Mary, built between 1163 and 1250.",
                                 LatitudeKey: @48.8530,
                                 LongitudeKey: @2.3498
                                 }
                             ];
    
    UIImage *pinImage = [UIImage imageNamed:@"active_grouped.png"];//[UIImage imageNamed:@"Pin"];
    CGPoint centerImagePoint = CGPointMake(pinImage.size.width/2-10 , pinImage.size.height/2-5);
    
    int i=1;
    for (NSDictionary *markerInfo in markerInfos) {
        GMSMarker *marker = [[GMSMarker alloc] init];
        
        marker.position = CLLocationCoordinate2DMake([markerInfo[LatitudeKey] doubleValue], [markerInfo[LongitudeKey] doubleValue]);
        marker.title = markerInfo[TitleKey];
        marker.icon = [self drawText:[NSString stringWithFormat:@"$ %d",i] inImage:pinImage atPoint:centerImagePoint];//pinImage;
        marker.userData = markerInfo;   
        marker.infoWindowAnchor = CGPointMake(0.5, 0.6);//CGPointMake(0.5, 0.25);
        marker.groundAnchor = CGPointMake(0.5, 1.0);
        marker.snippet = @"12";
        marker.map = mapView_;
        
        i++;
    }
}


-(UIView *)mapView:(GMSMapView *) aMapView markerInfoWindow:(GMSMarker*) marker
{
    
    //http://stackoverflow.com/questions/16746765/custom-info-window-for-google-maps
    //https://gist.github.com/jonfriskics/11200039
    
    
    
    UIView *view = [[UIView alloc]init];
    //customize the UIView, for example, in your case, add a UILabel as the subview of the view
    return view;
}

/*

- (void)addCircleToMap {
    
    NSArray *markerInfos = @[
                             @{
                                 TitleKey: @"Eiffel Tower",
                                 InfoKey: @"A wrought-iron structure erected in Paris in 1889. With a height of 984 feet (300 m), it was the tallest man-made structure for many years.",
                                 LatitudeKey: @48.8584,
                                 LongitudeKey: @2.2946
                                 },
                             @{
                                 TitleKey: @"Centre Georges Pompidou",
                                 InfoKey: @"Centre Georges Pompidou is a complex in the Beaubourg area of the 4th arrondissement of Paris. It was designed in the style of high-tech architecture.",
                                 LatitudeKey: @48.8607,
                                 LongitudeKey: @2.3524
                                 },
                             @{
                                 TitleKey: @"The Louvre",
                                 InfoKey: @"The principal museum and art gallery of France, in Paris.",
                                 LatitudeKey: @48.8609,
                                 LongitudeKey: @2.3363
                                 },
                             @{
                                 TitleKey: @"Arc de Triomphe",
                                 InfoKey: @"A ceremonial arch standing at the top of the Champs Élysées in Paris.",
                                 LatitudeKey: @48.8738,
                                 LongitudeKey: @2.2950
                                 },
                             @{
                                 TitleKey: @"Notre Dame",
                                 InfoKey: @"A Gothic cathedral in Paris, dedicated to the Virgin Mary, built between 1163 and 1250.",
                                 LatitudeKey: @48.8530,
                                 LongitudeKey: @2.3498
                                 }
                             ];
    
    
    int i=1;
    for (NSDictionary *markerInfo in markerInfos) {
        CLLocationCoordinate2D circleCenter =CLLocationCoordinate2DMake([markerInfo[LatitudeKey] doubleValue], [markerInfo[LongitudeKey] doubleValue]);
        GMSCircle *circ = [GMSCircle circleWithPosition:circleCenter
                                                 radius:1000];
        
        circ.fillColor = [UIColor colorWithRed:0.25 green:0 blue:0 alpha:0.05];
        circ.strokeColor = [UIColor yellowColor];
        circ.strokeWidth = 5;
        circ.title = [NSString stringWithFormat:@"$ %d",i];
        circ.map = mapView_;

        
        i++;
    }
}
*/

-(UIImage*) drawText:(NSString*) text
             inImage:(UIImage*)  image
             atPoint:(CGPoint)   point
{
    UIGraphicsBeginImageContext(image.size);
    [image drawInRect:CGRectMake(0,0,image.size.width,image.size.height)];
    CGRect rect = CGRectMake(point.x, point.y, image.size.width, image.size.height);
    [[UIColor whiteColor] set];
    
    UIFont *font = [UIFont boldSystemFontOfSize:12];
    if([text respondsToSelector:@selector(drawInRect:withAttributes:)])
    {
        //iOS 7
        NSDictionary *att = @{NSFontAttributeName:font};
        [text drawInRect:rect withAttributes:att];
    }
    else
    {
        //legacy support
        [text drawInRect:CGRectIntegral(rect) withFont:font];
    }
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}
@end
