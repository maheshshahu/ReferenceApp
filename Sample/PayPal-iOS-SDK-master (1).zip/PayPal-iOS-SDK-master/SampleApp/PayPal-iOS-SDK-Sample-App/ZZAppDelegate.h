//
//  ZZAppDelegate.h
//  PayPal-iOS-SDK-Sample-App
//

#import <UIKit/UIKit.h>

@interface ZZAppDelegate : UIResponder <UIApplicationDelegate>

@property(strong, nonatomic) UIWindow *window;

@end
