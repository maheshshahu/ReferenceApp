//
//  main.m
//  DYRateView
//
//  Created by Derek Yang on 05/17/12.
//  Copyright (c) 2012 www.iappexperience.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }

}