#import <UIKit/UIKit.h>

@interface HMSBAppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end
